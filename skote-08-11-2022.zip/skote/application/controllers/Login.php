<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

public function __construct(){
	parent::__construct();
		$this->load->model('User_model','admin');
		//$this->load->helper('custom_helper');
      
		}
	
	public function index()
	{
		//$this->load->view('welcome_message');
		$this->load->view('login');
	}




public function authenticate()
	{    

		$email = $this->input->post('email');
		$pass = $this->input->post('pass');


		$result = $this->admin->getid($email,$pass);
					$this->db->select('*');
					$this->db->where('email',$email);
					$user=$this->db->get('admin')->row_array();
					if($user){
				
						$this->session->set_userdata('email',$email);
						$this->session->set_userdata('id',$user['id']);
						
        
}
  redirect('/');


	}

	public function change_password(){
		$this->load->view('change_password');

	}

	


	public function change_password_1(){


$id=$_SESSION['id'];
		$confirm_new_password = $this->input->post('confirm_new_password');

$arr=array("password"=>$confirm_new_password);
$this->db->where('id',$id);
        $result= $this->db->update('admin',$arr);
       
redirect(base_url().'?msg=updated');

        }

}
 