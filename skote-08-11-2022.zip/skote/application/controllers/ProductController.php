<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductController extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	
	
	
	
	public function category_view()
	{
	$data['data'] = $this->ProductModel->readData_all('category');
		$this->load->view('category',$data);
	}
	
	
	public function subcategory_view()
	{
	$data['data'] = $this->ProductModel->readData_all('subcategory');
	$data['data1'] = $this->ProductModel->readData_all('category');
		$this->load->view('subcategory',$data);
	}
	
	public function category_form()
	{
	
		$this->load->view('add_category');
	}
	
	public function addCategory()
	{
	$category=$this->input->post('category');
	$arr=array('category'=>$category);
	$lastid = $this->ProductModel->insertData('category',$arr);
		redirect('ProductController/category_view?msg=cat_add');
	}
	
	public function form(){
	
	//echo $id.'aaaa';
	$data['data1'] = $this->ProductModel->readData_all('category');
	
		$this->load->view('form',$data);

	}
	
	public function ajax_subcategory(){
	$id=$this->input->post('id');
	$data['data2'] = $this->ProductModel->readData_where_1('subcategory',array('category' => $id));
	echo $this->db->last_query();
	$row=$data['data2'];
	//print_r($row);
	
	foreach($row as $res){
	echo "<option value='".$res['id']."'>".$res['subcategory']."</option>";
	}
	
	
	}
	
	public function addSubCategory()
	{
	$subcategory=$this->input->post('subcategory');
	$category=$this->input->post('category');
	$arr=array('subcategory'=>$subcategory,'category'=>$category);
	$lastid = $this->ProductModel->insertData('subcategory',$arr);
		redirect('ProductController/subcategory_view?msg=subcat_add');
	}
	
	
	public function addProduct()
	{
		$base =  $_SERVER['DOCUMENT_ROOT'];  
		if($_FILES['display_image']['name']){
			$temp= explode('.',$_FILES['display_image']['name']);
			$extension = end($temp);
			$randFile = rand(100000000,999999999).rand(1000000,9999999).".".$extension;
			move_uploaded_file($_FILES['display_image']['tmp_name'],$base."/skote/assets/singleProductImg/".$randFile);
		}
		
		$data = [
			'product_name'=>$this->input->post('product_name'),
			'cost_price'=>$this->input->post('cost_price'),
			'selling_price'=>$this->input->post('selling_price'),
			'display_image'=>$randFile??"",
			'sku'=>$this->input->post('sku'),
			'description'=>$this->input->post('description'),
			'category'=>$this->input->post('category'),
			'subcategory'=>$this->input->post('subcategory'),
			'status'=>$this->input->post('status'),
			'quantity'=>$this->input->post('quantity'),
		];
		$lastid = $this->ProductModel->insertData('products',$data);
		
		$total = count($_FILES['image']['name']);
		for( $i=0 ; $i < $total ; $i++ ) {

			$tmpFilePath = $_FILES['image']['tmp_name'][$i];

			if ($tmpFilePath != ""){
				$temp= explode('.',$_FILES['image']['name'][$i]);
				$extension = end($temp);
				$randFileMulti = rand(100000000,999999999).rand(1000000,9999999).".".$extension;
				
				$newFilePath = $base."/skote/assets/multiProductImg/".$randFileMulti;

				if(move_uploaded_file($tmpFilePath, $newFilePath)) {
					$arr = [
					'name'=>$randFileMulti,
					'product_id'=>$lastid,
					];
				$this->ProductModel->insertData('productImages',$arr);

				}
			}
		}
		
		redirect('ProductController/readProduct?msg=pro_add');
	}
	
	
	
	public function readProduct(){
	
	$data['data'] = $this->ProductModel->readData_all('products');
	
	
	$this->load->view('product',$data);
	
	}
	/*public function editProduct(){
	$this->load->view('edit_product');
	
	}*/ 
	
		public function editProduct(){
	$id=$this->input->get('id');
	//echo $id;die;
	$data['data'] = $this->ProductModel->readData_where('products',array('id' => $id));
	$data['data1'] = $this->ProductModel->readData_where_1('productImages',array('product_id' => $id));
	//print_r($data);die;
	$this->load->view('edit_product',$data);
	
	}
	
	public function editCategory(){
	$id=$this->input->post('id');
	$category=$this->input->post('category1');
	
	$arr=array('category'=>$category);
	$this->ProductModel->update('category',$id,$arr);
	redirect('ProductController/category_view?msg=cat_edit');
	}
	
	public function editSubCategory(){
	$id=$this->input->post('id');
	//echo $id;die;
	$subcategory=$this->input->post('subcategory1');
	$category=$this->input->post('category1');
	
	$arr=array('subcategory'=>$subcategory,'category'=>$category);
	
	$this->ProductModel->update('subcategory',$id,$arr);
	redirect('ProductController/subcategory_view?msg=subcat_edit');
	}
	
	public function deleteCategory(){
	$id = $this->input->get('id'); 
	 $this->ProductModel->delete('category',array('id' => $id));
redirect('ProductController/category_view?msg=cat_del');
	}
	
	public function deleteSubCategory(){
	$id = $this->input->get('id'); 
	 $this->ProductModel->delete('subcategory',array('id' => $id));
redirect('ProductController/subcategory_view?msg=subcat_del');
	}
	
	public function deleteProduct(){
	$id = $this->input->get('id'); 
	 $this->ProductModel->delete('products',array('id' => $id));
redirect('ProductController/readProduct?msg=pro_del');
	}
	
	public function delete_display_image(){
	
	$id=$this->input->post('id');
	
	
	$arr=array('display_image'=>NULL);
	
	$this->ProductModel->update('products',$id,$arr);
	//echo $this->db->last_query();
	echo "success";
//redirect('ProductController/readProduct?msg=pro_del');
	}
	
	public function delete_image(){
	
	$id=$this->input->post('id');
	
	
	
	$lastid=$this->ProductModel->delete('productImages',array('id' => $id));
	//$this->ProductModel->update('productImages',$id,$arr);
	//echo $this->db->last_query();
	return $lastid;
//redirect('ProductController/readProduct?msg=pro_del');
	}
	
	public function editProduct_id()
	{
	 
	 $id=$this->input->post('id');
	 	$base =  $_SERVER['DOCUMENT_ROOT']; 
		echo $_FILES['display_image']['name'];
		if(!empty($_FILES['display_image']['name'])){
		
		
			$temp= explode('.',$_FILES['display_image']['name']);
			$extension = end($temp);
			$randFile = rand(100000000,999999999).rand(1000000,9999999).".".$extension;
			move_uploaded_file($_FILES['display_image']['tmp_name'],$base."/skote/assets/singleProductImg/".$randFile);
		
		
		$data = [
			'product_name'=>$this->input->post('product_name'),
			'cost_price'=>$this->input->post('cost_price'),
			'selling_price'=>$this->input->post('selling_price'),
			'display_image'=>$randFile??"",
			'sku'=>$this->input->post('sku'),
			'description'=>$this->input->post('description'),
			'category'=>$this->input->post('category'),
			'subcategory'=>$this->input->post('subcategory'),
			'status'=>$this->input->post('status'),
			'quantity'=>$this->input->post('quantity'),
		];
		$lastid = $this->ProductModel->update('products',$id,$data);
		}
		$total = count($_FILES['image']['name']);
		for( $i=0 ; $i < $total ; $i++ ) {

			$tmpFilePath = $_FILES['image']['tmp_name'][$i];

			if ($tmpFilePath != ""){
				$temp= explode('.',$_FILES['image']['name'][$i]);
				$extension = end($temp);
				$randFileMulti = rand(100000000,999999999).rand(1000000,9999999).".".$extension;
				
				$newFilePath = $base."/skote/assets/multiProductImg/".$randFileMulti;

				if(move_uploaded_file($tmpFilePath, $newFilePath)) {
					$arr = [
					'name'=>$randFileMulti,
					'product_id'=>$id,
					];
				$this->ProductModel->insertData('productImages',$arr);

				}
			}
		}
		//$this->ProductModel->update('products',$data,array('id' => 1));
	redirect('ProductController/readProduct?msg=pro_edit');
	}
}
