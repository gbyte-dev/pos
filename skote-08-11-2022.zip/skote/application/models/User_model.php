<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

public function getid($email,$pass){

		$this->db->select('*');
		$this->db->from('admin');
		$this->db->where(array('email'=>$email,'password'=>$pass));
		$query = $this->db->get()->row_array();
		if(!empty($query)){
			return $query;
		}
		else{
			return 0;
		}
}



	}