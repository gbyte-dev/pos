<?php 
	
	$id=$_POST['id'];