<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Add Product</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="../assets/images/favicon.ico">


    <!-- Bootstrap Css -->
    <link href="../assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo base_url()?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="../assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    <link href="<?php echo base_url()?>assets/css/main.css" rel="stylesheet" type="text/css" />
    
    <!-- Custom Css-->
    <link href="<?php echo base_url()?>assets/css/custom.css" rel="stylesheet" type="text/css" />
<link href="../assets/libs/admin-resources/rwd-table/rwd-table.min.css" rel="stylesheet" type="text/css" />
</head>
<style>
	
	.table-rep-plugin .btn-toolbar {
    display: none;
}
	</style>
<body data-sidebar="dark">

    <!-- Begin page --> 
    <div id="layout-wrapper">

       <?php include ('includes/header.php');?>
        <!-- ========== Left Sidebar Start ========== -->
          <?php include ('includes/sidebar.php');?>
        <!-- Left Sidebar End -->

        <div class="main-content" id="result">

	
	
	
	
	
	<!-- Responsive Table css -->

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="page-content">
<?php if(isset($_GET['msg'])&& $_GET['msg']=='pro_add'){?>
	<script>
	Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Product Added Succesfully',
  showConfirmButton: false,
  timer: 1500
})
</script>
	
<?php }if(isset($_GET['msg']) && $_GET['msg']=='pro_del'){?>
<script>
	Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Product Deleted Succesfully',
  showConfirmButton: false,
  timer: 1500
})
</script>

<?php }if(isset($_GET['msg']) && $_GET['msg']=='pro_edit'){ ?>

<script>
	Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Product Updated Succesfully',
  showConfirmButton: false,
  timer: 1500
})
</script>

<?php } ?>
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Products</h4>

                    <!--div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                            <li class="breadcrumb-item active">Responsive Tables</li>
                        </ol>
                    </div-->

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <a href="<?php echo base_url().'ProductController/form'?>" class="btn btn-primary pull-right">Add Product</a>
                      

                        <div class="table-rep-plugin">
                            <div class="table-responsive mb-0" data-pattern="priority-columns">
                                <table id="tech-companies-1" class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Id</th>
                                            <th class="text-center">Product Name</th>
                                            <th class="text-center">Cost Price</th>
                                            <th class="text-center">Selling Price</th>
                                            <th class="text-center">SKU</th>
                                            
                                            <th class="text-center">Quantity</th>
											<th class="text-center">Image</th>
											<th class="text-center">Status</th>
											<th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php foreach($data as $res){?>
                                        <tr>
<td class="text-center"><?php echo $res['id'];?></td>
<td class="text-center"><?php echo $res['product_name'];?></td>
<td class="text-center"><?php echo $res['cost_price'];?></td>
<td class="text-center"><?php echo $res['selling_price'];?></td>
<td class="text-center"><?php echo $res['sku'];?></td>

<td class="text-center"><?php echo $res['quantity'];?></td>
<?php if($res['display_image']){?>
<td class="text-center"><img src="<?php echo base_url()?>/assets/singleProductImg/<?php echo $res['display_image'];?>" height="60" width="100" /></td>
<?php }else{?>
<td>No Image</td>
<?php } ?>
<td class="text-center"><?php echo $res['status'];?></td>
<td class="text-center">
<a href="<?php echo base_url().'ProductController/editProduct?id='.$res['id'];?>" class="btn btn-success btn-primary">Edit</a>
<a onclick="remove('<?php echo base_url().'ProductController/deleteProduct?id='.$res['id'];?>')" class="btn btn-danger btn-secondary">Delete</a>
	
	</td>
                                        </tr>
									<?php } ?>
                                    
                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<!-- Responsive Table js -->


        </div>

        <?php include('includes/footer.php');?>
    </div>
    <!-- END layout-wrapper -->

    <!-- Right Sidebar -->
    
    <!-- /Right-bar -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
	 <script src="../assets/libs/jquery/jquery.min.js"></script>
<script src="../assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

<!-- Init js -->
<script src="../assets/js/pages/table-responsive.init.js"></script>
   
    <script src="<?php echo base_url()?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/metismenu/metismenu.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/node-waves/waves.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCtSAR45TFgZjOs4nBFFZnII-6mMHLfSYI"></script>

    <!-- App js -->
    
   <script>
	   
	   function remove(url){
	   
	   
	   Swal.fire({
  title: 'Are you sure?',
  text: "It Will Delete the Row!",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.isConfirmed) {
    window.location = url;
  }
})
	   }
	   </script> 

</body>

</html>