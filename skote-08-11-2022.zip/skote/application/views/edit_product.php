<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Edit Product</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo base_url()?>assets/images/favicon.ico">


    <!-- Bootstrap Css -->
    <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo base_url()?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo base_url()?>assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    <link href="<?php echo base_url()?>assets/css/main.css" rel="stylesheet" type="text/css" />
    
    <!-- Custom Css-->
    <link href="<?php echo base_url()?>assets/css/custom.css" rel="stylesheet" type="text/css" />

</head>
<style>
	
	.mb-4 {
    margin-bottom: 1rem!important;
}

</style>
<body data-sidebar="dark">

    <!-- Begin page --> 
    <div id="layout-wrapper">

       <?php include ('includes/header.php');?>
        <!-- ========== Left Sidebar Start ========== -->
          <?php include ('includes/sidebar.php');?>
        <!-- Left Sidebar End -->

        <div class="main-content" id="result">
            <br/>   <br/>   <br/>   <br/>   <br/>
			<div class="row">
           <?php //foreach($data as $res){?>
            <!-- end col -->

            <div class="col-xl-6" style="margin:auto;">
                <div class="card" style="margin-bottom:60px;">
                    <div class="card-body">
                        <h4 class="card-title mb-4">Edit Product</h4>

                        <form action="<?= base_url() ?>ProductController/editProduct_id" method="post" enctype='multipart/form-data'>
                            <div class="row mb-4">
							<input type="hidden" name="id" value="<?php echo $data['id'];?>">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Product name</label>
                                <div class="col-sm-9">
                                  <input type="text" name="product_name" class="form-control" id="horizontal-firstname-input" placeholder="Enter Product Name" value="<?php echo $data['product_name'];?>" required>
                                </div>
                            </div>

                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Cost Price</label>
                                <div class="col-sm-9">
                                  <input type="text" name="cost_price" class="form-control" id="horizontal-firstname-input" placeholder="Enter Cost Price" value="<?php echo $data['cost_price'];?>" required>
                                </div>
                            </div>
                           
                            <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Selling Price</label>
                                <div class="col-sm-9">
                                  <input type="text" name="selling_price" class="form-control" id="horizontal-firstname-input" placeholder="Enter Selling Price" value="<?php echo $data['selling_price'];?>" required>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Images</label>
                                <div class="col-sm-9">
                                  <input type="file" name="image[]" class="form-control" id="horizontal-firstname-input" placeholder="Enter Your " multiple>
                                </div>
								<br/><br/><br/><div class="row">
								<?php foreach($data1 as $res){if($res['name']){?>
								
								<div class="col-md-4 " id="images_<?php echo $res['id']; ?>"><img src="<?php echo base_url()?>assets/multiProductImg/<?php echo $res['name'];?>" height="100%" width="100%" /><span style="font-size:13px;cursor:pointer;" id="image_<?php echo $res['id']; ?>" onclick="del(<?php echo $res['id']; ?>)">&#x2715;</span></div>
								<?php }}?>
								</div>
                            </div>
<br/>
                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Display Image</label>
                                <div class="col-sm-9">
                                  <input type="file" name="display_image" class="form-control" id="horizontal-firstname-input" placeholder="Enter Your ">
								  
                                </div>
								
								<?php if($data['display_image']){?>
								<br/><br/><br/>
							 <div class="col-md-4 m-auto" id="disp_image"><img src="<?php echo base_url()?>/assets/singleProductImg/<?php echo $data['display_image'];?>" height="100%" width="100%" /><span style="font-size:13px;cursor:pointer;" id="d_image">&#x2715;</span></div>
								<?php } ?>
                            </div>
<br/>
                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">SKU</label>
                                <div class="col-sm-9">
                                  <input type="text" name="sku" class="form-control" id="horizontal-firstname-input" placeholder="Enter SKU " value="<?php echo $data['sku'];?>" required>
                                </div>
                            </div>


                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Description</label>
                                <div class="col-sm-9">
                                  <input type="text" name="description" class="form-control" id="horizontal-firstname-input" placeholder="Enter Description " value="<?php echo $data['description'];?>" required>
                                </div>
                            </div>

                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Category</label>
                                <div class="col-sm-9">
                                 <select name="category" class="form-control">
                                    <option value="0">Select Category</option>
                                    <option value="1" <?php if($data['category']==1){echo "Selected";}?>>Category</option>
                                    <option value="2" <?php if($data['category']==2){echo "Selected";}?>>Category</option>
									<option value="3" <?php if($data['category']==3){echo "Selected";}?>>Category</option>
                                    <option value="4" <?php if($data['category']==4){echo "Selected";}?>>Category</option>
                                    
                                 </select>
                                </div>
                            </div>

                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Sub Category</label>
                                <div class="col-sm-9" class="form-control">
                                 <select name="subcategory" class="form-control">
                                    <option value="0">Select Sub Category</option>
                                    <option value="1" <?php if($data['subcategory']==1){echo "Selected";}?>>Sub Category</option>
                                    <option value="2" <?php if($data['subcategory']==2){echo "Selected";}?>>Sub Category</option>
                                    <option value="3" <?php if($data['subcategory']==3){echo "Selected";}?>>Sub Category</option>
                                    <option value="4" <?php if($data['subcategory']==4){echo "Selected";}?>>Sub Category</option>
                                    <option value="5" <?php if($data['subcategory']==5){echo "Selected";}?>>Sub Category</option>
                                 </select>
                                </div>
                            </div>

							<div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Quantity</label>
                                <div class="col-sm-9">
                                  <input type="text" name="quantity" class="form-control" id="horizontal-firstname-input" placeholder="Enter Quantity " value="<?php echo $data['quantity'];?>" required>
                                </div>
                            </div>

                             <div class="row mb-4">
                                <label for="horizontal-firstname-input" class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                  <input type="text" name="status" class="form-control" id="horizontal-firstname-input" placeholder="Enter Your " value="<?php echo $data['status'];?>" required>
                                </div>
                            </div>

                            <div class="row justify-content-end">
                                <div class="col-sm-9">
                                    <div>
                                        <button type="submit" class="btn btn-primary w-md">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- end card body -->
                </div>
				<br/>
                <!-- end card -->
            </div>
            <!-- end col -->
        </div>
        </div>

        <?php include('includes/footer.php');?>
    </div>
    <!-- END layout-wrapper -->


    <!-- /Right-bar -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="<?php echo base_url()?>assets/libs/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/metismenu/metismenu.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo base_url()?>assets/libs/node-waves/waves.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCtSAR45TFgZjOs4nBFFZnII-6mMHLfSYI"></script>

    <!-- App js -->
    <script>
		$('#d_image').click(function(){
		
		var id=<?php echo $_GET['id'];?>;
		
		$.ajax({
  url: "<?php echo base_url()?>ProductController/delete_display_image",
   data: {id : id},
   type:"POST",
  cache: false,
  success: function(html){
    $("#disp_image").html('');
  }
});
		});
		
		
		function del(id){
		
		$.ajax({
  url: "<?php echo base_url()?>ProductController/delete_image",
   data: {id : id},
   type:"POST",
  cache: false,
  success: function(html){
  
    $("#images_"+id).html('');
  }
});
		}
		
		</script>
    
</body>

</html>